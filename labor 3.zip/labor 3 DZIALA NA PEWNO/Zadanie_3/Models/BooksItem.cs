﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Zadanie_3.Models
{
    public class BooksItem
    {
        public long Id { get; set; }
        public string tytul { get; set; }
        public string autor { get; set; }
        public string Secret { get; set; }
    }
}
