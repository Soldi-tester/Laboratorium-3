﻿using Microsoft.EntityFrameworkCore;

namespace Zadanie_3.Models
{
    public class OsobyContext : DbContext
    {

        public OsobyContext(DbContextOptions<OsobyContext> options)
            : base(options)
        {
        }

        public DbSet<OsobyItem> OsobyItems { get; set; }
    }
}
