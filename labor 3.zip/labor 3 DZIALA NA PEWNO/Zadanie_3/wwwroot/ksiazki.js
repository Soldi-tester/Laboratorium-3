﻿const uri = "https://localhost:44354/api/BooksItems";
let ksionzki = null;
function getCount(data) {
    const el = $("#counter");
    let tytul = "ksiazka";
    if (data) {
        if (data > 1) {
            tytul = "ksiazki";
        }
        el.text(data + " " + tytul);
    } else {
        el.text("Brak");
    }
}
$(document).ready(function () {
    getData();
});
function getData() {
    $.ajax({
        type: "GET",
        url: uri,
        cache: false,
        success: function (data) {
            const tBody = $("#ksionzki");
            $(tBody).empty();
            getCount(data.length);
            $.each(data, function (key, item) {
                const tr = $("<tr></tr>")
                    .append($("<td></td>").text(item.autor))
                    .append($("<td></td>").text(item.tytul))
                    .append(
                        $("<td></td>").append(
                            $("<button>Edycja</button>").on("click", function () {
                                editItem(item.id);
                            })
                        )
                    )
                    .append(
                        $("<td></td>").append(
                            $("<button>Usuń</button>").on("click", function () {
                                deleteItem(item.id);
                            })
                        )
                    );
                tr.appendTo(tBody);
            });
            ksionzki = data;
        }
    });
}
function addItem() {
    const item = {
        tytul: $("#add-tytul").val(),
        autor: $("#add-autor").val(),
    };
    $.ajax({
        type: "POST",
        accepts: "application/json",
        url: uri + '/CreateBooksItem',
        contentType: "application/json",
        data: JSON.stringify(item),
        error: function (jqXHR, textStatus, errorThrown) {
            alert("Something went wrong!");
        },
        success: function (result) {
            getData();
            $("#add-tytul").val("");
        }
    });
}

function deleteItem(id) {
    $.ajax({
        url: uri + "/" + id,
        type: "DELETE",
        success: function (result) {
            getData();
        }
    });
}

function editItem(id) {
    $.each(ksionzki, function (key, item) {
        if (item.id === id) {
            $("#edit-tytul").val(item.tytul);
            $("#edit-id").val(item.id);
            $("#edit-autor").val(item.autor);
        }
    });
    $("#spoiler").css({ display: "block" });
}

function updateItem() {
    var id = parseInt($("#edit-id").val(), 10);
    const item = {
        id: id,
        tytul: $("#edit-tytul").val(),
        autor: $("#edit-autor").val(),
    };
    $.ajax({
        type: "POST",
        accepts: "application/json",
        url: uri + '/UpdateBooksItem',
        contentType: "application/json",
        data: JSON.stringify(item),
        error: function (jqXHR, textStatus, errorThrown) {
            alert("Something went wrong!");
        },
        success: function (result) {
            getData();
            closeInput();
        }
    });
}

function closeInput() {
    $("#spoiler").css({ display: "none" });
}