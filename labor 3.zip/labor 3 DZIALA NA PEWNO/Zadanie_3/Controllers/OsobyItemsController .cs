﻿using Zadanie_3.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Zadanie_3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OsobyItemsController : ControllerBase
    {
        private readonly OsobyContext _context;

        public OsobyItemsController(OsobyContext context)
        {
            _context = context;
        }

        // GET: api/OsobyItems
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OsobyItemDTO>>> GetOsobyItems()
        {
            return await _context.OsobyItems
                .Select(x => ItemToDTO(x))
                .ToListAsync();
        }

        // GET: api/OsobyItems/5
        [HttpGet("{id}")]
        public async Task<ActionResult<OsobyItemDTO>> GetOsobyItem(long id)
        {
            var OsobyItem = await _context.OsobyItems.FindAsync(id);
            if (OsobyItem == null)
            {
                return NotFound();
            }

            return ItemToDTO(OsobyItem);
        }

        [HttpPost]
        [Route("UpdateOsobyItem")]
        public async Task<ActionResult<OsobyItemDTO>> UpdateOsobyItem(OsobyItemDTO OsobyItemDTO)
        {
            var OsobyItem = await _context.OsobyItems.FindAsync(OsobyItemDTO.Id);
            if (OsobyItem == null)
            {
                return NotFound();
            }
            OsobyItem.Surname = OsobyItemDTO.Surname;
            OsobyItem.Name = OsobyItemDTO.Name;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!OsobyItemExists(OsobyItemDTO.Id))
            {
                return NotFound();
            }

            return CreatedAtAction(
                nameof(UpdateOsobyItem),
                new { id = OsobyItem.Id },
                ItemToDTO(OsobyItem));
        }

        [HttpPost]
        [Route("CreateOsobyItem")]
        public async Task<ActionResult<OsobyItemDTO>> CreateOsobyItem(OsobyItemDTO OsobyItemDTO)
        {
            var OsobyItem = new OsobyItem
            {
                Surname = OsobyItemDTO.Surname,
                Name = OsobyItemDTO.Name
            };

            _context.OsobyItems.Add(OsobyItem);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetOsobyItem),
                new { id = OsobyItem.Id },
                ItemToDTO(OsobyItem));
        }

        // DELETE: api/OsobyItems/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<OsobyItem>> DeleteOsobyItem(long id)
        {
            var OsobyItem = await _context.OsobyItems.FindAsync(id);
            if (OsobyItem == null)
            {
                return NotFound();
            }
            _context.OsobyItems.Remove(OsobyItem);
            await _context.SaveChangesAsync();
            return NoContent();
        }


        private bool OsobyItemExists(long id) =>
            _context.OsobyItems.Any(e => e.Id == id);

        private static OsobyItemDTO ItemToDTO(OsobyItem OsobyItem) =>
            new OsobyItemDTO
            {
                Id = OsobyItem.Id,
                Name = OsobyItem.Name,
                Surname = OsobyItem.Surname,
            };
    }
}
