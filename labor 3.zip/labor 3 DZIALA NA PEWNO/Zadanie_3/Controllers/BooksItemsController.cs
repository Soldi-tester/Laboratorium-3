﻿using Zadanie_3.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Zadanie_3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksItemsController : ControllerBase
    {
        private readonly BooksContext _context;

        public BooksItemsController(BooksContext context)
        {
            _context = context;
        }

        // GET: api/BooksItem
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BooksItemDTO>>> GetBooksItem()
        {
            return await _context.BooksItems
                .Select(x => ItemToDTO(x))
                .ToListAsync();
        }

        // GET: api/BooksItem/5
        [HttpGet("{id}")]
        public async Task<ActionResult<BooksItemDTO>> GetBooksItem(long id)
        {
            var BooksItem = await _context.BooksItems.FindAsync(id);
            if (BooksItem == null)
            {
                return NotFound();
            }

            return ItemToDTO(BooksItem);
        }

        [HttpPost]
        [Route("UpdateBooksItem")]
        public async Task<ActionResult<BooksItemDTO>> UpdateBooksItem(BooksItemDTO BooksItemDTO)
        {
            var BooksItem = await _context.BooksItems.FindAsync(BooksItemDTO.Id);
            if (BooksItem == null)
            {
                return NotFound();
            }
            BooksItem.autor = BooksItemDTO.autor;
            BooksItem.tytul = BooksItemDTO.tytul;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException) when (!BooksItemExists(BooksItemDTO.Id))
            {
                return NotFound();
            }

            return CreatedAtAction(
                nameof(UpdateBooksItem),
                new { id = BooksItem.Id },
                ItemToDTO(BooksItem));
        }

        [HttpPost]
        [Route("CreateBooksItem")]
        public async Task<ActionResult<BooksItemDTO>> CreateBooksItem(BooksItemDTO BooksItemDTO)
        {
            var BooksItem = new BooksItem
            {
                autor = BooksItemDTO.autor,
                tytul = BooksItemDTO.tytul
            };

            _context.BooksItems.Add(BooksItem);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetBooksItem),
                new { id = BooksItem.Id },
                ItemToDTO(BooksItem));
        }

        // DELETE: api/BooksItem/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<BooksItem>> DeleteBooksItem(long id)
        {
            var BooksItem = await _context.BooksItems.FindAsync(id);
            if (BooksItem == null)
            {
                return NotFound();
            }
            _context.BooksItems.Remove(BooksItem);
            await _context.SaveChangesAsync();
            return NoContent();
        }


        private bool BooksItemExists(long id) =>
            _context.BooksItems.Any(e => e.Id == id);

        private static BooksItemDTO ItemToDTO(BooksItem BooksItem) =>
            new BooksItemDTO
            {
                Id = BooksItem.Id,
                tytul = BooksItem.tytul,
                autor = BooksItem.autor,
            };
    }
}
